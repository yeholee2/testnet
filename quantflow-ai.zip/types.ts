export interface StockData {
  id: string;
  name: string;
  code: string;
  price: number;
  changeRate: number;
  rsScore: number; // Relative Strength
  volumeState: 'High' | 'Normal' | 'Low';
  chartData: { value: number }[];
  fitness: 'High' | 'Medium' | 'Low';
}

export interface MarketSector {
  name: string;
  strength: number; // 0-100
  changeRate: number;
  size: number; // For bubble size
}

export interface NewsKeyword {
  id: string;
  keyword: string;
  impact: 'Positive' | 'Negative' | 'Neutral';
  relatedStocks: { name: string; change: number }[];
}

export interface TradingSignal {
  id: string;
  time: string;
  title: string;
  description: string;
  type: 'Buy' | 'Sell' | 'Info';
  tags: string[];
  returnRate?: number;
}
