import { StockData, MarketSector, NewsKeyword, TradingSignal } from './types';

export const STOCK_INSIGHTS: StockData[] = [
  {
    id: '1',
    name: 'NVIDIA',
    code: 'NVDA',
    price: 875.28,
    changeRate: 3.12,
    rsScore: 96,
    volumeState: 'High',
    fitness: 'High',
    chartData: [
      { value: 820 }, { value: 845 }, { value: 830 }, { value: 860 }, { value: 855 }, { value: 875 }
    ]
  },
  {
    id: '2',
    name: 'Tesla',
    code: 'TSLA',
    price: 175.34,
    changeRate: -1.2,
    rsScore: 45,
    volumeState: 'Normal',
    fitness: 'Low',
    chartData: [
      { value: 182 }, { value: 180 }, { value: 178 }, { value: 179 }, { value: 176 }, { value: 175 }
    ]
  },
  {
    id: '3',
    name: 'Microsoft',
    code: 'MSFT',
    price: 420.55,
    changeRate: 1.5,
    rsScore: 88,
    volumeState: 'High',
    fitness: 'High',
    chartData: [
      { value: 410 }, { value: 412 }, { value: 415 }, { value: 418 }, { value: 419 }, { value: 420 }
    ]
  }
];

export const MARKET_SECTORS: MarketSector[] = [
  { name: 'AI 반도체', strength: 98, changeRate: 4.2, size: 100 },
  { name: '클라우드', strength: 85, changeRate: 1.8, size: 90 },
  { name: '전기차', strength: 40, changeRate: -2.1, size: 80 },
  { name: '비만 치료제', strength: 92, changeRate: 3.5, size: 85 },
  { name: '빅테크', strength: 78, changeRate: 1.1, size: 95 },
  { name: '에너지', strength: 65, changeRate: 0.5, size: 70 },
];

export const AI_KEYWORDS: NewsKeyword[] = [
  { 
    id: 'k1', 
    keyword: 'Fed 금리 인하', 
    impact: 'Positive', 
    relatedStocks: [{ name: 'TQQQ', change: 4.5 }, { name: 'Apple', change: 2.1 }] 
  },
  { 
    id: 'k2', 
    keyword: '엔비디아 실적 발표', 
    impact: 'Positive', 
    relatedStocks: [{ name: 'NVDA', change: 3.1 }, { name: 'AMD', change: 2.8 }] 
  },
  { 
    id: 'k3', 
    keyword: 'CPI 쇼크', 
    impact: 'Negative', 
    relatedStocks: [{ name: 'SPY', change: -1.2 }, { name: 'Tesla', change: -3.5 }] 
  },
  { 
    id: 'k4', 
    keyword: '오픈AI 소라(Sora)', 
    impact: 'Positive', 
    relatedStocks: [{ name: 'Adobe', change: -1.4 }, { name: 'Google', change: 1.2 }] 
  }
];

export const TRADING_SIGNALS: TradingSignal[] = [
  {
    id: 't1',
    time: '23:30',
    title: '신고가 돌파 감지',
    description: '52주 신고가를 강한 거래량과 함께 돌파했습니다.',
    type: 'Buy',
    tags: ['RS80↑', '거래량 200%'],
    returnRate: 12.4
  },
  {
    id: 't2',
    time: '22:15',
    title: '지지선 테스트',
    description: '20일 이동평균선 지지 여부를 테스트 중입니다.',
    type: 'Info',
    tags: ['MA20', '눌림목'],
  },
  {
    id: 't3',
    time: '04:45',
    title: '차익 실현 경보',
    description: 'RSI 과매수 구간(75 이상) 진입, 단기 조정 가능성.',
    type: 'Sell',
    tags: ['RSI 다이버전스'],
    returnRate: -1.2
  }
];

export const TRADER_RADAR_DATA = [
  { subject: '모멘텀', A: 120, fullMark: 150 },
  { subject: '거래량', A: 98, fullMark: 150 },
  { subject: '변동성', A: 86, fullMark: 150 },
  { subject: '추세', A: 99, fullMark: 150 },
  { subject: '펀더멘탈', A: 85, fullMark: 150 },
  { subject: '수급', A: 65, fullMark: 150 },
];