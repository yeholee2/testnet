import React from 'react';
import { Menu, Search, User } from 'lucide-react';
import StockInsights from './components/StockInsights';
import MarketIssues from './components/MarketIssues';
import AiPickWords from './components/AiPickWords';
import AiAssistant from './components/AiAssistant';
import TraderMode from './components/TraderMode';

// Import Data
import { 
  STOCK_INSIGHTS, 
  MARKET_SECTORS, 
  AI_KEYWORDS, 
  TRADING_SIGNALS,
  TRADER_RADAR_DATA
} from './constants';

const App: React.FC = () => {
  return (
    <div className="min-h-screen bg-[#F2F4F6] pb-20">
      {/* Sticky Header */}
      <header className="sticky top-0 z-50 bg-[#F2F4F6]/90 backdrop-blur-md px-4 py-4 flex justify-between items-center max-w-2xl mx-auto w-full">
        <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-blue-500 rounded-lg flex items-center justify-center text-white font-bold text-lg shadow-blue-200 shadow-lg">
                Q
            </div>
            <h1 className="text-xl font-extrabold text-gray-900 tracking-tight">QuantFlow</h1>
        </div>
        <div className="flex items-center gap-4 text-gray-600">
            <button><Search size={24} /></button>
            <button><Menu size={24} /></button>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="max-w-2xl mx-auto px-4 flex flex-col gap-4">
        
        {/* Section 1: Insights */}
        <StockInsights data={STOCK_INSIGHTS} />

        {/* Section 2: Market Issues */}
        <MarketIssues sectors={MARKET_SECTORS} />

        {/* Section 4: AI Assistant (Placed here for mobile flow priority) */}
        <AiAssistant signals={TRADING_SIGNALS} />

        {/* Section 3: Keywords */}
        <AiPickWords keywords={AI_KEYWORDS} />

        {/* Section 5: Trader Mode */}
        <TraderMode radarData={TRADER_RADAR_DATA} />

      </main>

      {/* Floating Bottom Nav for Mobile Feel */}
      <nav className="fixed bottom-0 left-0 w-full bg-white border-t border-gray-100 py-3 px-6 flex justify-between items-center text-xs font-medium text-gray-400 z-50 md:hidden">
        <div className="flex flex-col items-center gap-1 text-gray-900">
            <div className="w-6 h-6 bg-gray-900 rounded-full"></div>
            <span>홈</span>
        </div>
        <div className="flex flex-col items-center gap-1">
            <div className="w-6 h-6 bg-gray-200 rounded-full"></div>
            <span>피드</span>
        </div>
        <div className="flex flex-col items-center gap-1">
             <div className="w-6 h-6 bg-gray-200 rounded-full"></div>
            <span>자산</span>
        </div>
        <div className="flex flex-col items-center gap-1">
             <div className="w-6 h-6 bg-gray-200 rounded-full"></div>
            <span>메뉴</span>
        </div>
      </nav>
      
      {/* Footer for Desktop */}
      <footer className="hidden md:block text-center text-gray-400 text-sm py-10">
        &copy; 2024 QuantFlow AI. All rights reserved.
      </footer>
    </div>
  );
};

export default App;