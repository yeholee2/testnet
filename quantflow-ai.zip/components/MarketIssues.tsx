import React from 'react';
import { MarketSector } from '../types';
import { TrendingUp, Activity } from 'lucide-react';

interface Props {
  sectors: MarketSector[];
}

const MarketGauge = ({ value }: { value: number }) => {
  // Simple SVG Gauge
  const radius = 40;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (value / 100) * circumference;

  return (
    <div className="relative flex flex-col items-center justify-center">
      <svg width="120" height="120" className="transform -rotate-90">
        <circle
          cx="60"
          cy="60"
          r={radius}
          fill="transparent"
          stroke="#E5E7EB"
          strokeWidth="10"
        />
        <circle
          cx="60"
          cy="60"
          r={radius}
          fill="transparent"
          stroke={value > 50 ? "#F04452" : "#3182F6"}
          strokeWidth="10"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          strokeLinecap="round"
          className="transition-all duration-1000 ease-out"
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="text-2xl font-bold text-gray-900">{value}</span>
        <span className="text-xs text-gray-500 font-medium">시장 강도</span>
      </div>
    </div>
  );
};

const MarketIssues: React.FC<Props> = ({ sectors }) => {
  const sortedSectors = [...sectors].sort((a, b) => b.strength - a.strength);

  return (
    <section className="py-8 bg-white rounded-3xl p-6 shadow-sm border border-gray-100 my-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
            <div className="p-2 bg-blue-50 rounded-full">
                <Activity className="text-blue-500 w-5 h-5"/>
            </div>
            <h2 className="text-xl font-bold text-gray-900">시장 주요 이슈</h2>
        </div>
        <span className="text-xs text-gray-400 font-medium">{new Date().toLocaleDateString('ko-KR')}</span>
      </div>

      <div className="flex flex-col lg:flex-row gap-8">
        {/* Left: Market Strength */}
        <div className="flex-shrink-0 bg-gray-50 rounded-2xl p-6 flex flex-col items-center justify-center min-w-[200px]">
          <h3 className="text-sm font-semibold text-gray-500 mb-4">현재 시장 에너지</h3>
          <MarketGauge value={78} />
          <div className="mt-4 text-center">
            <p className="text-sm font-bold text-red-500">강력 매수 우위</p>
            <p className="text-xs text-gray-400 mt-1">유동성이 공급되고 있습니다</p>
          </div>
        </div>

        {/* Right: Sector Heatmap Grid */}
        <div className="flex-1">
          <h3 className="text-sm font-semibold text-gray-500 mb-4 ml-1">주도 섹터</h3>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            {sortedSectors.map((sector, idx) => {
              const isPositive = sector.changeRate > 0;
              // Dynamic sizing logic visually (simulating bubble map with grid)
              const spanClass = idx === 0 ? 'col-span-2 row-span-2' : 'col-span-1 row-span-1';
              const heightClass = idx === 0 ? 'h-40' : 'h-full min-h-[100px]';
              
              return (
                <div 
                  key={sector.name} 
                  className={`
                    ${spanClass} ${heightClass}
                    relative p-4 rounded-2xl flex flex-col justify-between transition-all hover:scale-[1.02] cursor-pointer
                    ${isPositive ? 'bg-red-50 hover:bg-red-100' : 'bg-blue-50 hover:bg-blue-100'}
                  `}
                >
                  <div className="flex justify-between items-start">
                     <span className={`text-sm md:text-base font-bold ${isPositive ? 'text-gray-800' : 'text-gray-800'}`}>
                      {sector.name}
                    </span>
                    {idx === 0 && <TrendingUp size={16} className="text-red-500" />}
                  </div>
                  
                  <div className="flex items-end gap-1">
                     <span className={`text-2xl font-bold ${isPositive ? 'text-red-500' : 'text-blue-500'}`}>
                        {sector.changeRate > 0 ? '+' : ''}{sector.changeRate}%
                     </span>
                     <span className="text-xs text-gray-500 mb-1">평균</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};

export default MarketIssues;