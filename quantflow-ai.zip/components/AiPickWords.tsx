import React, { useState } from 'react';
import { NewsKeyword } from '../types';
import { Sparkles, ChevronDown, ChevronUp, ExternalLink } from 'lucide-react';
import { AnimatePresence, motion } from 'framer-motion';

interface Props {
  keywords: NewsKeyword[];
}

const KeywordCard: React.FC<{ 
    data: NewsKeyword; 
    isActive: boolean; 
    onClick: () => void;
}> = ({ data, isActive, onClick }) => {
  return (
    <div className="mb-3">
      <button 
        onClick={onClick}
        className={`
            w-full flex items-center justify-between p-4 rounded-2xl transition-all duration-300
            ${isActive 
                ? 'bg-gray-900 text-white shadow-lg scale-[1.01]' 
                : 'bg-white text-gray-800 hover:bg-gray-50 border border-gray-100'}
        `}
      >
        <div className="flex items-center gap-3">
            <span className={`
                flex items-center justify-center w-6 h-6 rounded-full text-xs font-bold
                ${isActive ? 'bg-white text-black' : 'bg-gray-100 text-gray-500'}
            `}>
                #
            </span>
            <span className="font-semibold text-lg">{data.keyword}</span>
        </div>
        <div className="flex items-center gap-2">
             <span className={`text-xs px-2 py-0.5 rounded-full ${
                 isActive ? 'bg-white/20 text-white' : 
                 data.impact === 'Positive' ? 'bg-red-50 text-red-500' : 'bg-blue-50 text-blue-500'
             }`}>
                {data.impact === 'Positive' ? '호재' : data.impact === 'Negative' ? '악재' : '중립'}
             </span>
             {isActive ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
        </div>
      </button>

      {/* Accordion Content */}
      <div 
        className={`
            overflow-hidden transition-all duration-300 ease-in-out
            ${isActive ? 'max-h-48 opacity-100 mt-2' : 'max-h-0 opacity-0'}
        `}
      >
        <div className="bg-white rounded-2xl p-4 border border-gray-100 shadow-sm">
            <p className="text-xs text-gray-400 mb-2 font-semibold uppercase tracking-wider">관련 종목</p>
            <div className="grid grid-cols-2 gap-2">
                {data.relatedStocks.map((stock, idx) => (
                    <div key={idx} className="flex justify-between items-center p-2 bg-gray-50 rounded-lg">
                        <span className="text-sm font-medium text-gray-700">{stock.name}</span>
                        <span className={`text-sm font-bold ${stock.change >= 0 ? 'text-red-500' : 'text-blue-500'}`}>
                            {stock.change > 0 ? '+' : ''}{stock.change}%
                        </span>
                    </div>
                ))}
            </div>
            <div className="mt-3 flex justify-end">
                <button className="text-xs text-blue-500 flex items-center gap-1 hover:underline">
                    심층 분석 보기 <ExternalLink size={10} />
                </button>
            </div>
        </div>
      </div>
    </div>
  );
};

const AiPickWords: React.FC<Props> = ({ keywords }) => {
  const [activeId, setActiveId] = useState<string | null>(keywords[0].id);

  return (
    <section className="py-8">
      <div className="flex items-center gap-2 mb-6 px-2">
        <Sparkles className="text-purple-500 w-5 h-5 animate-pulse" />
        <h2 className="text-xl font-bold text-gray-900">AI 추천 키워드</h2>
      </div>

      <div className="flex flex-col">
        {keywords.map(kw => (
          <KeywordCard 
            key={kw.id} 
            data={kw} 
            isActive={activeId === kw.id}
            onClick={() => setActiveId(activeId === kw.id ? null : kw.id)}
          />
        ))}
      </div>
    </section>
  );
};

export default AiPickWords;