import React from 'react';
import { TradingSignal } from '../types';
import { Bell, Info, ArrowRight } from 'lucide-react';

interface Props {
  signals: TradingSignal[];
}

const AiAssistant: React.FC<Props> = ({ signals }) => {
  return (
    <section className="py-8 bg-gray-900 text-white rounded-3xl p-6 shadow-xl relative overflow-hidden">
      {/* Background glow effect */}
      <div className="absolute top-0 right-0 w-64 h-64 bg-blue-500 rounded-full mix-blend-multiply filter blur-[80px] opacity-20 animate-pulse"></div>

      <div className="flex justify-between items-center mb-8 relative z-10">
        <div>
            <h2 className="text-xl font-bold">AI 매매 비서</h2>
            <p className="text-gray-400 text-sm mt-1">실시간 포착 시그널</p>
        </div>
        <div className="p-2 bg-gray-800 rounded-full relative">
            <Bell size={20} className="text-white" />
            <span className="absolute top-0 right-0 w-2 h-2 bg-red-500 rounded-full border-2 border-gray-900"></span>
        </div>
      </div>

      <div className="space-y-6 relative z-10">
        {/* Timeline Line */}
        <div className="absolute left-[59px] top-4 bottom-4 w-0.5 bg-gray-700"></div>

        {signals.map((signal) => (
            <div key={signal.id} className="flex gap-4 group">
                {/* Time */}
                <div className="w-12 pt-1 flex-shrink-0 text-right">
                    <span className="text-xs font-mono text-gray-400">{signal.time}</span>
                </div>

                {/* Dot */}
                <div className="relative pt-1.5 flex-shrink-0 z-10">
                    <div className={`w-3 h-3 rounded-full border-2 border-gray-900 ${
                        signal.type === 'Buy' ? 'bg-red-500 shadow-[0_0_10px_rgba(239,68,68,0.5)]' : 
                        signal.type === 'Sell' ? 'bg-blue-500' : 'bg-gray-500'
                    }`}></div>
                </div>

                {/* Content Card */}
                <div className="flex-1 bg-gray-800/50 backdrop-blur-sm p-4 rounded-xl border border-gray-700/50 hover:bg-gray-800 transition-colors">
                    <div className="flex justify-between items-start mb-1">
                        <h3 className="font-bold text-white text-base">{signal.title}</h3>
                        {signal.returnRate && (
                            <span className={`text-lg font-black ${
                                signal.returnRate > 0 ? 'text-red-400' : 'text-blue-400'
                            }`}>
                                {signal.returnRate > 0 ? '+' : ''}{signal.returnRate}%
                            </span>
                        )}
                    </div>
                    
                    <p className="text-sm text-gray-300 mb-3 leading-relaxed">{signal.description}</p>
                    
                    {/* Tags & Tooltips */}
                    <div className="flex flex-wrap gap-2">
                        {signal.tags.map(tag => (
                            <div key={tag} className="group/tooltip relative">
                                <span className="px-2 py-1 bg-gray-700 rounded-md text-xs font-medium text-gray-300 border border-gray-600 flex items-center gap-1 cursor-help">
                                    {tag} <Info size={10} />
                                </span>
                                {/* Tooltip */}
                                <div className="absolute bottom-full left-0 mb-2 w-48 p-2 bg-black text-xs text-white rounded-lg opacity-0 group-hover/tooltip:opacity-100 transition-opacity pointer-events-none z-20">
                                    {tag}에 대한 설명입니다...
                                </div>
                            </div>
                        ))}
                    </div>

                    {signal.type !== 'Info' && (
                        <div className="mt-3 pt-3 border-t border-gray-700 flex items-center text-xs text-blue-300 font-semibold cursor-pointer hover:text-blue-200">
                            차트 확인하기 <ArrowRight size={12} className="ml-1"/>
                        </div>
                    )}
                </div>
            </div>
        ))}
      </div>
    </section>
  );
};

export default AiAssistant;