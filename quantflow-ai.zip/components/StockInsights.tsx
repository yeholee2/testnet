import React from 'react';
import { ResponsiveContainer, LineChart, Line } from 'recharts';
import { ArrowUp, ArrowDown, Zap, BarChart3 } from 'lucide-react';
import { StockData } from '../types';

interface Props {
  data: StockData[];
}

const StockCard: React.FC<{ stock: StockData }> = ({ stock }) => {
  const isPositive = stock.changeRate >= 0;
  
  return (
    <div className="bg-white p-5 rounded-3xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow duration-300 min-w-[280px] flex flex-col justify-between">
      <div>
        <div className="flex justify-between items-start mb-2">
          <div className="flex flex-col">
            <span className="text-gray-500 text-xs font-semibold tracking-wide">{stock.code}</span>
            <h3 className="text-lg font-bold text-gray-900">{stock.name}</h3>
          </div>
          <span className={`px-2 py-1 rounded-full text-xs font-bold ${
            stock.fitness === 'High' ? 'bg-red-50 text-red-500' : 'bg-blue-50 text-blue-500'
          }`}>
            적합도 {stock.fitness === 'High' ? '상' : stock.fitness === 'Medium' ? '중' : '하'}
          </span>
        </div>

        <div className="flex items-center space-x-2 mb-4">
          <span className={`text-2xl font-bold ${isPositive ? 'text-red-500' : 'text-blue-500'}`}>
            ${stock.price.toLocaleString()}
          </span>
          <div className={`flex items-center text-sm font-medium ${isPositive ? 'text-red-500' : 'text-blue-500'}`}>
            {isPositive ? <ArrowUp size={14} /> : <ArrowDown size={14} />}
            {Math.abs(stock.changeRate)}%
          </div>
        </div>

        <div className="flex space-x-2 mb-4">
            <div className="flex items-center space-x-1 bg-gray-50 px-2 py-1 rounded-lg">
                <Zap size={12} className="text-yellow-500" />
                <span className="text-xs text-gray-600 font-medium">RS점수 {stock.rsScore}</span>
            </div>
            <div className="flex items-center space-x-1 bg-gray-50 px-2 py-1 rounded-lg">
                <BarChart3 size={12} className="text-gray-400" />
                <span className="text-xs text-gray-600 font-medium">{stock.volumeState === 'High' ? '거래량 급증' : '거래량 보통'}</span>
            </div>
        </div>
      </div>

      <div className="h-16 w-full opacity-80">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={stock.chartData}>
            <Line 
              type="monotone" 
              dataKey="value" 
              stroke={isPositive ? '#F04452' : '#3182F6'} 
              strokeWidth={3} 
              dot={false} 
              isAnimationActive={true}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

const StockInsights: React.FC<Props> = ({ data }) => {
  return (
    <section className="py-8">
      <div className="flex flex-col md:flex-row md:items-end justify-between mb-6 px-4">
        <div>
          <h2 className="text-3xl font-extrabold text-gray-900 leading-tight">
            오늘의<br/>
            <span className="text-blue-500">시장 핵심 종목</span>
          </h2>
          <p className="text-gray-500 mt-2 text-sm">RS 점수와 거래량을 기반으로 AI가 선별했습니다.</p>
        </div>
        <button className="hidden md:block text-sm font-semibold text-gray-400 hover:text-gray-900 transition-colors mt-4 md:mt-0">
          전체 보기 &rarr;
        </button>
      </div>

      <div className="overflow-x-auto no-scrollbar pb-4 px-4 -mx-4 md:mx-0">
        <div className="flex space-x-4 w-max md:w-full">
          {data.map(stock => (
            <StockCard key={stock.id} stock={stock} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default StockInsights;