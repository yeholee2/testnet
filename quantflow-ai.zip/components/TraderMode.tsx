import React from 'react';
import { Radar, RadarChart, PolarGrid, PolarAngleAxis, ResponsiveContainer } from 'recharts';
import { Crosshair, Smartphone } from 'lucide-react';

interface Props {
  radarData: any[];
}

const TraderMode: React.FC<Props> = ({ radarData }) => {
  const US_TICKERS = ['AAPL', 'TSLA', 'AMZN', 'GOOGL', 'META'];

  return (
    <section className="py-8">
       <div className="flex items-center justify-between mb-6 px-2">
        <div className="flex items-center gap-2">
            <Crosshair className="text-gray-900 w-6 h-6" />
            <h2 className="text-2xl font-extrabold text-gray-900">프로 트레이더 모드</h2>
        </div>
        <button className="bg-gray-900 text-white px-4 py-2 rounded-full text-sm font-bold flex items-center gap-2 shadow-lg hover:bg-gray-800 transition-colors">
            <Smartphone size={16} /> HTS 모드
        </button>
      </div>

      <div className="bg-white rounded-3xl p-6 shadow-sm border border-gray-100 flex flex-col md:flex-row gap-8">
        
        {/* Radar Chart Area */}
        <div className="flex-1 min-h-[300px] relative">
            <h3 className="absolute top-0 left-0 text-sm font-semibold text-gray-500 z-10">시장 정밀 진단</h3>
            <ResponsiveContainer width="100%" height="100%">
                <RadarChart cx="50%" cy="50%" outerRadius="70%" data={radarData}>
                <PolarGrid stroke="#E5E7EB" />
                <PolarAngleAxis dataKey="subject" tick={{ fill: '#6B7280', fontSize: 12, fontWeight: 600 }} />
                <Radar
                    name="Market"
                    dataKey="A"
                    stroke="#3182F6"
                    strokeWidth={3}
                    fill="#3182F6"
                    fillOpacity={0.2}
                />
                </RadarChart>
            </ResponsiveContainer>
            <div className="absolute bottom-0 right-0 bg-blue-50 px-3 py-1 rounded-lg">
                <span className="text-blue-600 text-sm font-bold">종합 점수: 88/100</span>
            </div>
        </div>

        {/* Real-time Ranking Table (Mini HTS) */}
        <div className="flex-1">
            <div className="flex justify-between items-center mb-4 border-b border-gray-100 pb-2">
                <h3 className="text-sm font-semibold text-gray-900">실시간 거래량 상위 (US)</h3>
                <span className="text-xs text-red-500 animate-pulse font-medium">● 실시간</span>
            </div>
            
            <div className="space-y-1">
                {[1, 2, 3, 4, 5].map((rank) => (
                    <div key={rank} className="flex items-center justify-between p-3 hover:bg-gray-50 rounded-xl cursor-pointer transition-colors group">
                        <div className="flex items-center gap-3">
                            <span className={`
                                w-5 h-5 flex items-center justify-center text-xs font-bold rounded
                                ${rank <= 3 ? 'bg-gray-900 text-white' : 'bg-gray-200 text-gray-500'}
                            `}>{rank}</span>
                            <span className="font-medium text-gray-700 group-hover:text-black">{US_TICKERS[rank-1]}</span>
                        </div>
                        <div className="text-right">
                             <div className={`text-sm font-bold ${rank % 2 === 0 ? 'text-blue-500' : 'text-red-500'}`}>
                                {rank % 2 === 0 ? '-' : '+'}{Math.floor(Math.random() * 10)}.{Math.floor(Math.random() * 9)}%
                             </div>
                             <div className="text-xs text-gray-400">{Math.floor(Math.random() * 500)}M Vol</div>
                        </div>
                    </div>
                ))}
            </div>
            
            <button className="w-full mt-4 py-3 bg-gray-50 text-gray-600 text-sm font-bold rounded-xl hover:bg-gray-100 transition-colors">
                전체 순위 보기
            </button>
        </div>

      </div>
    </section>
  );
};

export default TraderMode;